#include "main.h"


MT linktosensor (const char *ipaddr)
{
	int ret = 0;
	MT sclient;

	//设置超时时间
	struct timeval timeout = {3,0};

	struct sockaddr_in seraddr;
	memset(&seraddr, 0, sizeof(seraddr));

	//端口设置
    seraddr.sin_family = AF_INET;
    seraddr.sin_port = htons(IP_PORT); //监听端口
    seraddr.sin_addr.s_addr = inet_addr(ipaddr);
    //inet_pton(AF_INET, ipaddr, (void*)&seraddr.sin_addr.S_un.S_addr);

    //创建套接字
 	sclient.sensorclient = socket(AF_INET, SOCK_STREAM, 0);//IPPROTO_TCP
	if (-1 == sclient.sensorclient  )
    {
        printf("invalid linktosensor socket error!\n");
        exit(-1);
    }  

    //设置阻塞模式
    unsigned long st = 1;
    // int sv = ioctl(sclient.sensorclient, F_GETFL, (unsigned long *)&st);//Windows为：ioctlsocket; linux :fcntl
    // cout << "sv = " << sv << endl;
    int flags = fcntl(sclient.sensorclient, F_GETFL, 0);
    fcntl(sclient.sensorclient, flags|O_NONBLOCK);


    int confd = connect(sclient.sensorclient, (sockaddr*)&seraddr, sizeof(seraddr));
    //cout << "confd = " << confd << endl; 
    if (confd < 0)
    {
	    	
	    

	    fd_set r;
	    FD_ZERO(&r);
	    FD_SET(sclient.sensorclient, &r);
	    ret = select(sclient.sensorclient+1, NULL, &r, NULL, &timeout);
	    if (ret <= 0)
	    {

	        sclient.key = -1;
	        printf("connect %s error !\n", ipaddr);
	        close(sclient.sensorclient);
	        return sclient;
	    }
	    else
	    {
	        std::cout << "connect "<< ipaddr << " success !" << endl;
	    }
	}
	else
	{
		printf("connect %s success \n",ipaddr);
	}

    //设置为阻塞状态
    usleep(100);
    st = 0;
    ret = ioctl(sclient.sensorclient, FIONBIO, (unsigned long*)&st);

	//cout << "linktosensor sclient = " << sclient.sensorclient << endl;

	return sclient;
}


//把数据发送到传感器。参数SOCKET sclient：所连接的端口，const char *data：发送的数据，len：发送数据的长度
SF sendtosensor(int sclient, const char *data, int len )
{
    //int nNetTimeout = 2000ms;
    SF mystatustime;
    int ret;


    //数据发送
    //send(sclient, data, len, MSG_DONTROUTE);
    int timeout = 3000;//超时时间，单位为微妙
    // if (::setsockopt(sclient,SOL_SOCKET,SO_SNDTIMEO,(char *)&timeout,sizeof(timeout))==SOCKET_ERROR)
    // {
    //     cout << "sendtosensor timeout" << endl;       
    // }

    //cout << "start send" << endl;
    ret = send(sclient, data, len, 0); 
    //cout << "send ret = " << ret << endl;

    //数据接收
    char recData[1024] = {0};
    timeout = 3000;//超时时间，单位为微妙
    // int to = setsockopt(sclient, SOL_SOCKET, SO_RCVTIMEO, (char*)&timeout, sizeof(timeout));
    // if (to == SOCKET_ERROR)
    // {
    //     //cout << " recieved timeout" << endl;
    //     printf("recieved timeout\n");    
    // }

    //cout << "sizeof(recData) = " << sizeof(recData) << endl;
    ret = recv(sclient, recData, sizeof(recData), 0);
    //cout << "recv ret = " << ret << endl;

    // DWORD dwerro = WSAGetLastError();
    // //cout << "dwerro = " << dwerro << endl;
    // if (dwerro == 10060)//由于连接方在一段时间后没有正确的答复或连接的主机没有反应，连接尝试失败。
    // {
    //     mystatustime.key = -3;
    // }

    //cout << "回传的数据长度：" << ret << endl;
    unsigned char rxdt[64] = { 0 };
    if (ret > 0)
    {
        // recData[ret] = 0x00;
         printf("The data received is :\n");
        for (size_t i = 0; i < ret; i++)
        {
           // printf("%02X  ", recData[i]);
            rxdt[i] = recData[i];
        }
        //printf("\n"); 
        //printf("=========================:\n");
        int len = ret;

        for (size_t i = 0; i < len; i++)
        {
            printf("%02X  ", rxdt[i]);
        }
        printf("\n");
    }
    mystatustime.electricity = (double)(((rxdt[5] << 8) | rxdt[6]) / 100.0000);
    //printf("The current magnitude is:%4f \n", mystatustime.electricity);


    close(sclient);

    return mystatustime;
}



//连接到后台服务器
int linktoserver(const char* ipaddr_server)
{
    int scl;
    sockaddr_in Addr;
    int ret = 0;
    memset(&Addr, 0, sizeof(Addr));

    //链接服务器
    scl = socket(AF_INET, SOCK_STREAM, 0); //客户端套接字IPPROTO_TCP
    if (scl == -1)
    {
        printf("invalid %s socket!\n", ipaddr_server);
        return 0;
    }

    //设置为非阻塞状态


    //端口设置
    Addr.sin_family = AF_INET;
    Addr.sin_port = htons(6688); //监听端口
    Addr.sin_addr.s_addr = inet_addr(ipaddr_server);
    ret = connect(scl, (sockaddr*)&Addr, sizeof(Addr));//与指定IP地址和端口的服务端连接
    if (-1 == ret)
    {
    	printf("connect %s error\n", ipaddr_server);
    }
    else
    {
    	printf("connect %s success\n", ipaddr_server);
    }
    //cout << "linkserver connect ret = " << ret << endl;

    fd_set r;
    FD_ZERO(&r);
    FD_SET(scl, &r);
    //设置超时时间
    struct timeval timeout = { 3,0 };

    //cout << "linkserver dwerro = " << dwerro << endl;

    // ret = select(0, 0, &r, 0, &timeout);
    // if (ret <= 0)
    // {
    //     //printf("linkserver connect %s error !\n", ipaddr_server);
    //     //设置为阻塞状态
    //     Sleep(20);
    //     st = 0;
    //     ret = ioctl(scl, FIONBIO, (unsigned long*)&st);
    //     close(scl);
    //     return dwerro;
    // }
    //else
    //{
    //    std::cout << "connect " << ipaddr_server << " success !" << endl;
    //}

    //设置为阻塞状态





    return scl;
}



//把数据发送到后台服务器
int sendtoserver(int scl,const char *data,int rx_len, int status, double electricity)
{
    int tx, ret = 0;
    int timeout = 3000;//超时时间，单位为微妙
    int len = strlen(data);
    // if (::setsockopt(scl, SOL_SOCKET, SO_SNDTIMEO, (char*)&timeout, sizeof(timeout)) == -1)
    // {
    //     cout << "sendtoserver send timeout" << endl;
    // }
    
    //cout << "strlen(data) = " << strlen(data) << endl;//发送的数据长度查看
    //数据发送，参数scl：所发送的连接端，data：发送的数据，256：所发送数据的长度
    cout << "send to server data is " << data;
    tx = send(scl, data, len, 0);  
    //cout << "sendtoserver ret = " << tx  << endl;

 
    close(scl);
    return ret;
}




